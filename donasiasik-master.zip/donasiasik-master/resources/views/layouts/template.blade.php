@include('layouts.nav')
@yield('konten')
@include('layouts.footer')