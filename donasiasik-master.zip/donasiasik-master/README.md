<p align="center"><a href="https://laravel.com" target="_blank"><img src="https://raw.githubusercontent.com/laravel/art/master/logo-lockup/5%20SVG/2%20CMYK/1%20Full%20Color/laravel-logolockup-cmyk-red.svg" width="400"></a></p>

<p align="center">
<a href="https://travis-ci.org/laravel/framework"><img src="https://travis-ci.org/laravel/framework.svg" alt="Build Status"></a>
<a href="https://packagist.org/packages/laravel/framework"><img src="https://img.shields.io/packagist/dt/laravel/framework" alt="Total Downloads"></a>
<a href="https://packagist.org/packages/laravel/framework"><img src="https://img.shields.io/packagist/v/laravel/framework" alt="Latest Stable Version"></a>
<a href="https://packagist.org/packages/laravel/framework"><img src="https://img.shields.io/packagist/l/laravel/framework" alt="License"></a>
</p>

## Cara Install

- Clone ke drive.
- Ketik di cmd "composer install" di folder yang sudah di clone.
- Selagi install, buat database.
- Setelah install composer, ketik "cp .env.example .env" dan setting .env sesuai database yang dipakai.
- Lalu ketik di cmd "php artisan key:generate".
- Setelah generate ketik di cmd "php artisan migrate" untuk mengekspor table.
- Untuk demo data ketik "php artisan db:seed"
- Setelah semua sudah di install, copy dan replace folder "ui" ke donasiasik/vendor/laravel .
- Ketik "php artisan serve" untuk menjalankan aplikasi.

Admin <br>
email: admin@gmail.com <br>
pass: 12345678 <br>
<br>
User <br>
email: user@gmail.com <br>
pass: 12345678 <br>

Enjoy the apps.

Kontak instagram @rizikhanafi untuk lebih lanjut.
